/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interdisciplinar;


import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author logonlb
 */
public class Interdisciplinar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        CaixaLapis cl = new CaixaLapis("",0);
        Caderno c = new Caderno("",0);
        Pedido pe = new Pedido();
        String aux = "";
        String aux1 = "C";
        int aux2;
        
        boolean confirma = true;
        
        ArrayList <Papel> papel = new ArrayList<>();
        ArrayList <Caderno> caderno = new ArrayList<>();
        ArrayList <CaixaLapis> cxlapis = new ArrayList<>();
        
        pe.setCaderno(caderno);
        pe.setCxlapis(cxlapis);
        pe.setPapel(papel);
        
        float totalpedido = 0;
        pe.setTotalpedido(totalpedido);
        
        String conf = "";
        
        while(!"5".equals(aux)){
        aux = JOptionPane.showInputDialog(null,"1 - Cadastrar novo produto"
                + "\n2 - Fazer um pedido"
                + "\n3 - Listar todos"
                + "\n4 - Consultar "
                + "\n5 - Sair");
        
        
        switch(aux){
            
            case "1":
            
            
            String prod = JOptionPane.showInputDialog(null, "Selecione um produto: "
                        + "\n1 - Papel"
                        + "\n2 - Caixa de Lápis"
                        + "\n3 - Caderno"
                        +"\n4 - Voltar");
            switch(prod){
                case "1":
                    
                    do {
                    Papel p = new Papel("",0);
                    p.cadastro();
                    papel.add(p);
                    
                    conf = JOptionPane.showInputDialog(null,"Deseja cadastrar outro Produto 'Papel'? \nDigite 'S' para Sim e 'N' para Não: ");
            if (conf.equalsIgnoreCase("s")){
                confirma = true;
            }
            else if (conf.equalsIgnoreCase("n")){
                confirma = false; }
                    }
                    while(confirma == true);
                          
                    
                    
                break;
                case "2":
                   do{
                    cl.cadastro();
                    cxlapis.add(cl);
                    }
                    while(cl.confirma == true);
                break;
                case "3":
                    do{
                    c.cadastro();
                    caderno.add(c);
                    }
                    while(c.confirma == true);
                break;
                case "4":
                break;
            }
            
            break;
            case "2":
                pe.cadastro();
                
              
                while(!"".equals(aux1)){
        aux1 = JOptionPane.showInputDialog(null, "Que tipo de produto será comprado?\n Digite:\n 'P' - Papel"
                + "\n'C' - Caderno "
                +"\n'CL' - Caixa de Lápis"
                + "\n'F' - Finalizar Pedido"
                +"\n\nAperte ENTER para Voltar!");
        
        
        
        switch(aux1){
            
            case "P":
                
                ArrayList <String> lista = new ArrayList();
                String msg = "";
                do{
                    
                    for(int i = 0;i < pe.getPapel().size();i++){
                        msg = "Papel\n"+(i+1)+")"+"Marca: "+pe.getPapel().get(i).getMarca() 
                                +"\nValor: "+pe.getPapel().get(i).getValor()
                                +"\nCor: "+pe.getPapel().get(i).getCor()
                                +"\nTipo: "+pe.getPapel().get(i).getTipo()
                                +"\nLargura: "+pe.getPapel().get(i).getLargura()
                                +"\nAltura: "+pe.getPapel().get(i).getAltura()
                                +"\nGramatura: "+pe.getPapel().get(i).getGramatura()
                                +"\nPaltado: "+pe.getPapel().get(i).isPaltado()+"\n";
                        lista.add(msg);
                        msg = "";
                    }
                    
                    
                    
                    String print = "";
        
        
	for (int i = 0; i < lista.size();i++){
            
           print += (i+1)+")"+ lista.get(i)+"\n\n";
        }
                    JOptionPane.showMessageDialog(null, print);
                    
                aux2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o número do produto para adicionar ao Pedido"));
                aux2 = aux2 - 1;
                
                for(int i = 0;i<pe.getPapel().size();i++){
                    if (i == aux2){
                        
                        totalpedido = pe.getPapel().get(i).getValor();
                    }
                }
                
               conf = JOptionPane.showInputDialog(null,"Deseja adicionar outro Papel no Pedido? \nDigite 'S' para Sim e 'N' para Não: ");
            if (conf.equalsIgnoreCase("s")){
                confirma = true;
            }
            else if (pe.conf.equalsIgnoreCase("n")){
                confirma = false;
            }
                }
                while(confirma == true);
             break;
            case "C":
                do{
                aux2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Escolha seu produto pelo número\n"+c.consulta()));
                
                for(int i = 1;i<c.lista.size();i++){
                    if (i == aux2){
                        totalpedido += Float.parseFloat(c.lista.get((int) c.getValor()));
                    }
                }
                
               conf = JOptionPane.showInputDialog(null,"Deseja adicionar outro Caderno no Pedido? \nDigite 'S' para Sim e 'N' para Não: ");
            if (conf.equalsIgnoreCase("s")){
                confirma = true;
            }
            else if (conf.equalsIgnoreCase("n")){
                confirma = false;
            }
                }
                while(confirma == true);
            break;
            case "CL":
                do{
                aux2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Escolha seu produto pelo número\n"+cx.consulta()));
                aux2--;
                
                for(int i = 0;i<cx.lista.size();i++){
                    if (i == (aux2)){
                        totalpedido += Float.parseFloat(cx.lista.get((int) cx.getValor()));
                    }
                }
                
               conf = JOptionPane.showInputDialog(null,"Deseja adicionar outra Caixa de Lápis no Pedido? \nDigite 'S' para Sim e 'N' para Não: ");
            if (conf.equalsIgnoreCase("s")){
                confirma = true;
            }
            else if (conf.equalsIgnoreCase("n")){
                confirma = false;
            }
                }
                while(confirma == true);
                
                
            break;
            case "F":
            
                JOptionPane.showMessageDialog(null,"Data: "+d.getDia()+"/"+d.getMes()+"/"+d.getAno()
                                                   +"\nCliente: "+c.getNome()+" CPF: "+c.getCpf()+" Telefone: "+c.getTelefone()
                                                   +"\nTotal Pedido: R$"+totalpedido);
                       
                
            break;
        }
                }
                
                
            
            break;


            case "3":
                
             JOptionPane.showMessageDialog(null,"Papel\n"+p.consulta()+"Caderno\n"+c.consulta()+
                                        "Caixa de Lápis\n"+cl.consulta());
                
                
            break; 
            case "4":
                prod = JOptionPane.showInputDialog(null, "Consulte um produto: "
                        + "\n1 - Papel"
                        + "\n2 - Caixa de Lápis"
                        + "\n3 - Caderno"
                        +"\n4 - Voltar");
                switch(prod){
                case "1":
                    
                    JOptionPane.showMessageDialog(null, p.consulta());
                break;
                case "2":
                     
                    JOptionPane.showMessageDialog(null,cl.consulta());
                break;
                case "3":
                    
                    JOptionPane.showMessageDialog(null,c.consulta());
                break;
                case "4":
                    break;
            case "5":
                System.exit(0);
            break;
              
        }
        }
        }
    }
        
    
    
}
