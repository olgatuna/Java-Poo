/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interdisciplinar;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class CaixaLapis extends Produto implements Manipulacao{
    
    private int quantidade;
    private boolean colorido;
    String resultado = "";
    boolean confirma = true;
    
    
    public CaixaLapis(String marca, float valor) {
        super(marca, valor);
    }

    public CaixaLapis(int quantidade, boolean colorido, String marca, float valor) {
        super(marca, valor);
        this.quantidade = quantidade;
        this.colorido = colorido;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public boolean isColorido() {
        return colorido;
    }

    public void setColorido(boolean colorido) {
        this.colorido = colorido;
    }

    
    ArrayList<String>caixalapis = new ArrayList();
    ArrayList<String> lista = new ArrayList();
    
    @Override
    public boolean cadastro() {
        
        String resp;
        String conf;
        
        
        
        do{
            super.setMarca(JOptionPane.showInputDialog(null, "Marca: "));
            resultado += "Marca: "+super.getMarca();
            lista.add(resultado);
            
            super.setValor(Float.parseFloat(JOptionPane.showInputDialog(null,"Valor: ")));
            resultado += "\nValor: "+super.getValor();
            lista.add(resultado);
            
            quantidade = Integer.parseInt(JOptionPane.showInputDialog(null,"Quantidade:"));
            resultado += "\nQuantidade: "+quantidade;
            lista.add(resultado);
            
            resp = JOptionPane.showInputDialog(null,"Colorido? \nDigite 'S' para Sim e 'N' para Não: ");
            resultado += "\nColorido: "+resp;
            lista.add(resultado);
            
            if ("S".equals(resp) || "s".equals(resp)){
                colorido = true;
            }
            else if ("N".equals(resp) || "n".equals(resp)){
                colorido = false;
            }
            
            
            caixalapis.add(resultado);
            
            conf = JOptionPane.showInputDialog(null,"Deseja cadastrar outro Produto 'Caixa de Lápis'? \nDigite 'S' para Sim e 'N' para Não: ");
            if (conf.equalsIgnoreCase("s")){
                confirma = true;
            }
            else if (conf.equalsIgnoreCase("n")){
                confirma = false;
            }
        }
        while(confirma == true);
        
       
       
        return confirma;
    }

    @Override
    public String consulta() {
        
      
        String msg = "";
        
        
	for (int i = 0; i < caixalapis.size();i++){
            
            msg += (i+1) +")"+ caixalapis.get(i)+"\n\n";
        }
	return msg;
        
    }
    
    
    
}
