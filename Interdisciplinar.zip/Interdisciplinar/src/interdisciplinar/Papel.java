/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interdisciplinar;


import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author logonlb
 */
public class Papel extends Produto implements Manipulacao{
    
    private String cor;
    private String tipo;
    private float largura;
    private float altura;
    private int gramatura;
    private boolean paltado;
    
    boolean confirma = true;
    
    public Papel(String marca, float valor) {
        super(marca, valor);
    }

    public Papel(String cor, String tipo, float largura, float altura, int gramatura, boolean paltado, String marca, float valor) {
        super(marca, valor);
        this.cor = cor;
        this.tipo = tipo;
        this.largura = largura;
        this.altura = altura;
        this.gramatura = gramatura;
        this.paltado = paltado;
    }

    

    

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getLargura() {
        return largura;
    }

    public void setLargura(float largura) {
        this.largura = largura;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public int getGramatura() {
        return gramatura;
    }

    public void setGramatura(int gramatura) {
        this.gramatura = gramatura;
    }

    public boolean isPaltado() {
        return paltado;
    }

    public void setPaltado(boolean paltado) {
        this.paltado = paltado;
    }

       
    String resultado = "";
    
    ArrayList<String>papel = new ArrayList();
    ArrayList<String> lista = new ArrayList();
   
    @Override
    public boolean cadastro() {
        
        String palt;
        String conf;
        
       
        
       
            super.setMarca(JOptionPane.showInputDialog(null, "Marca: "));
            resultado = "Marca: "+super.getMarca();
            lista.add(resultado);
            
            super.setValor(Float.parseFloat(JOptionPane.showInputDialog(null,"Valor: ")));
            resultado += "\nValor: "+super.getValor();
            lista.add(resultado);
            
            cor = JOptionPane.showInputDialog(null,"Cor:");
            resultado += "\nCor: "+cor;
            lista.add(resultado);
            
            tipo = JOptionPane.showInputDialog(null,"Tipo:");
            resultado += "\nTipo: "+tipo;
            lista.add(resultado);
            
            altura = Float.parseFloat(JOptionPane.showInputDialog(null,"Altura:"));
            resultado += "\nAltura: "+altura;
            lista.add(resultado);
            
            largura = Float.parseFloat(JOptionPane.showInputDialog(null,"Largura:"));
            resultado += "\nLargura: "+largura;
            lista.add(resultado);
            
            gramatura = Integer.parseInt(JOptionPane.showInputDialog(null,"Gramatura:"));
            resultado += "\nGramatura: "+gramatura;
            lista.add(resultado);
            
            palt = JOptionPane.showInputDialog(null,"Paltado? \nDigite 'S' para Sim e 'N' para Não: ");
            resultado += "\nPaltado: "+palt;
            lista.add(resultado);
            
            if ("S".equals(palt) || "s".equals(palt)){
                paltado = true;
            }
            else if ("N".equals(palt) || "n".equals(palt)){
                paltado = false;
            }
            
            papel.add(resultado);
            
        
            
            /*conf = JOptionPane.showInputDialog(null,"Deseja cadastrar outro Produto 'Papel'? \nDigite 'S' para Sim e 'N' para Não: ");
            if (conf.equalsIgnoreCase("s")){
                confirma = true;
            }
            else if (conf.equalsIgnoreCase("n")){
                confirma = false;
            }*/
        
        
        
        
       
       
        return confirma;
    }

    @Override
    public String consulta() {
        String msg = "";
        
        
	for (int i = 0; i < papel.size();i++){
            
            msg += (i+1)+")"+ papel.get(i)+"\n\n";
        }
	return msg;
    }
    
    
    
}
