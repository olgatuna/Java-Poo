/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interdisciplinar;

import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author logonlb
 */
public class Pedido implements Manipulacao{
    
    private Data data;
    private Cliente cliente;
    private float totalpedido;
    
    private ArrayList <CaixaLapis> cxlapis;
    private ArrayList <Papel> papel;
    private ArrayList <Caderno> caderno;

    String conf = "";
    boolean confirma = true;
    
    public Pedido() {
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public float getTotalpedido() {
        return totalpedido;
    }

    public void setTotalpedido(float totalpedido) {
        this.totalpedido = totalpedido;
    }

    public ArrayList<CaixaLapis> getCxlapis() {
        
        return cxlapis;
    }

    public void setCxlapis(ArrayList<CaixaLapis> cxlapis) {
        this.cxlapis = cxlapis;
    }

    public ArrayList<Papel> getPapel() {
        return papel;
    }

    public void setPapel(ArrayList<Papel> papel) {
        this.papel = papel;
    }

    public ArrayList<Caderno> getCaderno() {
        return caderno;
    }

    public void setCaderno(ArrayList<Caderno> caderno) {
        this.caderno = caderno;
    }

        Cliente c = new Cliente("","","");
        
        Data d = new Data(0,0,0);
        
        Caderno cad = new Caderno("",0);
        
        
        Papel pap = new Papel("",0);
        
        
        CaixaLapis cx = new CaixaLapis("",0);
    
    
    @Override
    public boolean cadastro() {
     
        
        //String resultado;
        //String aux = "a";
        //int aux2;
        
        
        
        c.setNome(JOptionPane.showInputDialog(null,"Qual o nome dx Cliente?"));
        //resultado = c.getNome();
        
        c.setCpf(JOptionPane.showInputDialog(null,"Qual o CPF dx Cliente?"));
        //resultado += c.getCpf();
        
        c.setTelefone(JOptionPane.showInputDialog(null,"Qual o telefone dx Cliente?"));
        //resultado += c.getTelefone();
        
        d.setDia(Integer.parseInt(JOptionPane.showInputDialog(null, "Que dia é hoje?")));
        //resultado += d.getDia();
        
        d.setMes(Integer.parseInt(JOptionPane.showInputDialog(null, "Que mês é hoje?")));
        //resultado += d.getMes();
        
        d.setAno(Integer.parseInt(JOptionPane.showInputDialog(null, "Que ano é hoje?")));
        //resultado += d.getAno();
       
        
        
        
        
        /*while(!"".equals(aux)){
        aux = JOptionPane.showInputDialog(null, "Que tipo de produto será comprado?\n Digite:\n 'P' - Papel"
                + "\n'C' - Caderno "
                +"\n'CL' - Caixa de Lápis"
                + "\n'F' - Finalizar Pedido"
                +"\n\nAperte ENTER para Voltar!");
        
        
        
        switch(aux){
            
            case "P":
                
                ArrayList <String> lista = new ArrayList();
                String msg = "";
                do{
                    
                    for(int i = 0;i < getPapel().size();i++){
                        msg += "Papel\n"+(i+1)+")"+"Marca: "+getPapel().get(i).getMarca() 
                                +"\nValor: "+getPapel().get(i).getValor()
                                +"\nCor: "+getPapel().get(i).getCor()
                                +"\nTipo: "+getPapel().get(i).getTipo()
                                +"\nLargura: "+getPapel().get(i).getLargura()
                                +"\nAltura: "+getPapel().get(i).getAltura()
                                +"\nGramatura: "+getPapel().get(i).getGramatura()
                                +"\nPaltado: "+getPapel().get(i).isPaltado()+"\n";
                        
                    }
                    
                    
                    
                    String print = "";
        
        
	for (int i = 0; i < lista.size();i++){
            
           print += (i+1)+")"+ lista.get(i)+"\n\n";
        }
                    JOptionPane.showMessageDialog(null, print);
                    
                aux2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o número do produto para adicionar ao Pedido"));
                aux2 = aux2 - 1;
                
                for(int i = 0;i<getPapel().size();i++){
                    if (i == aux2){
                        
                        totalpedido += getPapel().get(i).getValor();
                    }
                }
                
               conf = JOptionPane.showInputDialog(null,"Deseja adicionar outro Papel no Pedido? \nDigite 'S' para Sim e 'N' para Não: ");
            if (conf.equalsIgnoreCase("s")){
                confirma = true;
            }
            else if (conf.equalsIgnoreCase("n")){
                confirma = false;
            }
                }
                while(confirma == true);
             break;
            case "C":
                do{
                aux2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Escolha seu produto pelo número\n"+cad.consulta()));
                
                for(int i = 1;i<cad.lista.size();i++){
                    if (i == aux2){
                        totalpedido += Float.parseFloat(cad.lista.get((int) cad.getValor()));
                    }
                }
                
               conf = JOptionPane.showInputDialog(null,"Deseja adicionar outro Caderno no Pedido? \nDigite 'S' para Sim e 'N' para Não: ");
            if (conf.equalsIgnoreCase("s")){
                confirma = true;
            }
            else if (conf.equalsIgnoreCase("n")){
                confirma = false;
            }
                }
                while(confirma == true);
            break;
            case "CL":
                do{
                aux2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Escolha seu produto pelo número\n"+cx.consulta()));
                aux2--;
                
                for(int i = 0;i<cx.lista.size();i++){
                    if (i == (aux2)){
                        totalpedido += Float.parseFloat(cx.lista.get((int) cx.getValor()));
                    }
                }
                
               conf = JOptionPane.showInputDialog(null,"Deseja adicionar outra Caixa de Lápis no Pedido? \nDigite 'S' para Sim e 'N' para Não: ");
            if (conf.equalsIgnoreCase("s")){
                confirma = true;
            }
            else if (conf.equalsIgnoreCase("n")){
                confirma = false;
            }
                }
                while(confirma == true);
                
                
            break;
            case "F":
            
                JOptionPane.showMessageDialog(null,"Data: "+d.getDia()+"/"+d.getMes()+"/"+d.getAno()
                                                   +"\nCliente: "+c.getNome()+" CPF: "+c.getCpf()+" Telefone: "+c.getTelefone()
                                                   +"\nTotal Pedido: R$"+totalpedido);
                       
                
            break;
        }
        }*/
       return confirma; 
    }
        
    
    
    @Override
    public String consulta() 
        {
        String msg = "";
        
        for(Papel p : getPapel()){
             msg = p + "\n";
        }
 
        
        
        for(Caderno c : getCaderno()){
             msg += c + "\n";
        }
        
       
        
        for(CaixaLapis cx : getCxlapis()){
             msg += cx;
        }
        
        JOptionPane.showMessageDialog(null,msg);
        return msg;
    }
    
    public void calculaTotalPedido(){
    }
    
    
    
    
}
