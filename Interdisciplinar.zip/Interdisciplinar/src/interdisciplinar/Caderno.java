/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interdisciplinar;

import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author logonlb
 */
public class Caderno extends Produto implements Manipulacao{

    String resultado = "";
    
    private int qtdefolhas;
    private String tamanho;
    private String tipo;
    private boolean capadura;
    
    boolean confirma = true;
    
    public Caderno(String marca, float valor) {
        super(marca, valor);
    }

    public Caderno(int qtdefolhas, String tamanho, String tipo, boolean capadura, String marca, float valor) {
        super(marca, valor);
        this.qtdefolhas = qtdefolhas;
        this.tamanho = tamanho;
        this.tipo = tipo;
        this.capadura = capadura;
    }

    public int getQtdefolhas() {
        return qtdefolhas;
    }

    public void setQtdefolhas(int qtdefolhas) {
        this.qtdefolhas = qtdefolhas;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isCapadura() {
        return capadura;
    }

    public void setCapadura(boolean capadura) {
        this.capadura = capadura;
    }

    ArrayList<String>caderno = new ArrayList();
    ArrayList<String> lista = new ArrayList();
    
    @Override
    public boolean cadastro() {

        
        String cd;
        String conf;
        
        
        
        do{
            super.setMarca(JOptionPane.showInputDialog(null, "Marca: "));
            resultado += "Marca: "+super.getMarca();
            lista.add(resultado);
            
            super.setValor(Float.parseFloat(JOptionPane.showInputDialog(null,"Valor: ")));
            resultado += "\nValor: "+super.getValor();
            lista.add(resultado);
            
            qtdefolhas = Integer.parseInt(JOptionPane.showInputDialog(null,"Quantidade de Folhas:"));
            resultado += "\nQuantidade de Folhas: "+qtdefolhas;
            lista.add(resultado);
            
            tamanho = JOptionPane.showInputDialog(null,"Tamanho:");
            resultado += "\nTamanho: "+tamanho;
            lista.add(resultado);
            
            tipo = JOptionPane.showInputDialog(null,"Quantidade:");
            resultado += "\nTipo: "+tipo;
            lista.add(resultado);
           
            
            cd = JOptionPane.showInputDialog(null,"Capa dura? \nDigite 'S' para Sim e 'N' para Não: ");
            resultado += "\nCapa Dura: "+cd;
            lista.add(resultado);
            
            if ("S".equals(cd) || "s".equals(cd)){
                capadura = true;
            }
            else if ("N".equals(cd) || "n".equals(cd)){
               capadura = false;
            }
            
            caderno.add(resultado);
            
            conf = JOptionPane.showInputDialog(null,"Deseja cadastrar outro Produto 'Caderno'? \nDigite 'S' para Sim e 'N' para Não: ");
            if (conf.equalsIgnoreCase("s")){
                confirma = true;
            }
            else if (conf.equalsIgnoreCase("n")){
                confirma = false;
            }
        }
        while(confirma == true);
        
       
       
        return confirma;
    }    

    @Override
    public String consulta() {
    String msg = "";
        
        
	for (int i = 0; i < caderno.size();i++){
            
            msg += (i+1) +")"+ caderno.get(i)+"\n\n";
        }
	return msg;
    }
    
    
    
}
